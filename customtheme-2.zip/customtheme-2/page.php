<?php get_header(); ?>
<?php get_header('inner');
    the_post();
    ?>

<!-- hero section -->
<section class="sec-hero-01">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center main-hero-bg">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 hero-content">
                            <div class="hero-content">
                                <h1><?php the_title(); ?>: Get More Done with whitepace</h1>
                                <?php the_post_thumbnail(array(700,500)); ?>
                                <p><a href="<?php echo site_url(); ?>" <i> Home Page</i></a> <?php the_title(); ?>  <?php the_content(); ?>
                            </p>
                                <a href="#" class="main-btn-02">Try Whitepace free <i
                                        class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 hero-content-img">
                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/home-hero-01.png" alt="Hero Image" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- hero section end -->

<?php get_footer('inner'); ?>