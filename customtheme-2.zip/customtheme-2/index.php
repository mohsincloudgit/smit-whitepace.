
<?php get_header(); ?>
<?php get_header( 'inner' ); ?>


    <!-- hero section -->
    <section class="sec-hero-01">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center main-hero-bg">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 hero-content">
                            <div class="hero-content">
                                <h1>Get More Done with whitepace</h1>
                                <p>Project management software that enables your teams to collaborate, plan, analyze and
                                    manage everyday tasks</p>
                                <a href="#" class="main-btn-02">Try Whitepace free <i
                                        class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 hero-content-img">
                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/home-hero-01.png" alt="Hero Image" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- hero section end -->

    <!-- service section -->
    <section class="service-sec-01">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center g-3">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-sec">
                            <!-- <img src="assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                            <div class="service-content">
                                <h2>Project <br><span>Management</span></h2>
                                <p>Images, videos, PDFs and audio files are supported. Create math expressions and
                                    diagrams directly from the app. Take photos with the mobile app and save them to a
                                    note.</p>
                                <a href="#" class="main-btn-02">Try Whitepace free <i
                                        class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-content-img">
                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/service-01.webp" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section end -->

    <!-- service section 02 -->
    <section class="service-sec-02">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-content-img">
                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/sec-02.png" alt="" class="img-fluid">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-sec">
                            <!-- <img src="assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                            <div class="service-content-2">
                                <h2>Work <span>Together</span></h2>
                                <p>With whitepace, share your notes with your colleagues and collaborate on them.
                                    You can also publish a note to the internet and share the URL with others.
                                </p>
                                <a href="#" class="main-btn-02">Try It Now <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section end -->

    <!-- service section 03-->
    <section class="service-sec-03">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center">

                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-sec">
                            <!-- <img src="<?php bloginfo('template_directory'); ?>/assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                            <div class="service-content-3">
                                <h2>Use as <span>Extension</span></h2>
                                <p>Use the web clipper extension, available on Chrome and Firefox, to save web pages or
                                    take screenshots as notes.
                                </p>
                                <a href="#" class="main-btn-02">Lets Go <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-content-img">
                            <img src="assets/images/service-04.webp" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section end -->

    <!-- service section 04 -->
    <section class="service-sec-04">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-content-img">
                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/sec-03.png" alt="" class="img-fluid">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-sec">
                            <!-- <img src="assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                            <div class="service-content-4">
                                <h2>Customise it
                                    to <br><span>your needs</span></h2>
                                <p>Customise the app with plugins, custom themes and multiple text editors (Rich Text or
                                    Markdown). Or create your own scripts and plugins using the Extension API.</p>
                                <a href="#" class="main-btn-02">Let's Go <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section end -->

    <!-- service section 05 -->
    <section class="service-sec-05">
        <div class="container">
            <div class="row">


                <div class="col-lg-12 col-md-12 col-sm-12 col-12 service-sec">
                    <!-- <img src="assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                    <div class="service-content-5">
                        <h2>Choose <span>Your Plan</span></h2>
                        <p>Whether you want to get organized, keep your personal life on track, or boost
                            workplace productivity, Evernote has the right plan for you.</p>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <div class="service-content-5-1">
                                <span>Free</span>
                                <h3>$0</h3>
                                <p>Capture ideas and find them quickly</p>
                                <ul>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Sync unlimited devices</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> 10 GB monthly uploads
                                    </li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> 200 MB max. note size</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Customize Home dashboard and
                                        access extra widgets</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Connect primary Google Calendar
                                        account</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Add due dates, reminders, and
                                        notifications to your tasks</li>
                                </ul>
                                <a href="#" class="main-btn-02">Get Started <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <div class="service-content-5-1">
                                <span>Premium</span>
                                <h3>$11.99</h3>
                                <p>Keep home and family on track</p>
                                <ul>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Sync unlimited devices</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> 10 GB monthly uploads</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> 200 MB max. note size</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Customize Home dashboard and
                                        access extra widgets</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Connect primary Google Calendar
                                        account</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Add due dates, reminders, and
                                        notifications to your tasks</li>
                                </ul>
                                <a href="#" class="main-btn-02">Get Started <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <div class="service-content-5-1">
                                <span>Business</span>
                                <h3>$49.99</h3>
                                <p>Capture ideas and find them quickly</p>
                                <ul>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Sync unlimited devices</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> 10 GB monthly uploads
                                    </li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> 200 MB max. note size
                                    </li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Customize Home dashboard and
                                        access extra widgets</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Connect primary Google Calendar
                                        account</li>
                                    <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/check-icon.png" alt=""> Add due dates, reminders, and
                                        notifications to your tasks</li>
                                </ul>
                                <a href="#" class="main-btn-02">Get Started <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section end -->

    <!-- service section 6 -->
    <section class="service-sec-06">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12 service-sec">
                            <!-- <img src="assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                            <div class="service-content-6">
                                <h2>Your work, everywhere<span> you are</span></h2>
                                <p>Access your notes from your computer, phone or tablet by synchronising with various
                                    services, including whitepace, Dropbox and OneDrive. The app is available on
                                    Windows, macOS, Linux, Android and iOS. A terminal app is also available!</p>
                                <a href="#" class="main-btn-02">Try Taskey <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section end -->

    <!-- service section 07 -->
    <section class="service-sec-07">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center g-3">

                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-sec">
                            <!-- <img src="assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                            <div class="service-content-7">
                                <h2>100% <span>your data</span></h2>
                                <p>The app is open source and your notes are saved to an open format, so you'll always
                                    have access to them. Uses End-To-End Encryption (E2EE) to secure your notes and
                                    ensure no-one but yourself can access them.</p>
                                <a href="#" class="main-btn-02">Let's Go <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 service-content-img">
                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/sec-07.png" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section end -->


    <!-- service section 08 -->
    <section class="service-sec-08">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center">

                        <div class="col-lg-12 col-md-12 col-sm-12 col-12 service-sec">
                            <!-- <img src="assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                            <div class="service-content-8">
                                <h2>Our <span>Sponsors</span></h2>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section end -->



    <!--- slider slider 9--->
    <section class="slider-section">
        <ul class="slider">
            <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/Apple.png"></li>
            <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/Microsoft.png"></li>
            <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/Slack.png"></li>
            <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/Google.png"></li>
            <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/Apple.png"></li>
            <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/Microsoft.png"></li>
            <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/Slack.png"></li>
            <li><img src="<?php bloginfo('template_directory'); ?>/assets/images/Google.png"></li>
        </ul>
    </section>
    <!-- slider section end -->

    <!-- sec 10 start -->
    <section class="sec-hero-10">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center main-hero-bg">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 hero-content-img">
                            <img src="<?php bloginfo('template_directory'); ?>/assets/images/sec-10.png" alt="Hero Image" class="img-fluid">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 hero-content">
                            <div class="hero-content">
                                <h1>Work with Your Favorite Apps Using whitepace</h1>
                                <p>Whitepace teams up with your favorite software. Integrate with over 1000+ apps with
                                    Zapier to have all the tools you need for your project success.</p>
                                <a href="#" class="main-btn-02">Read More <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- sec 10 end -->

    <!-- service section 11 -->
    <section class="service-sec-11">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12 service-sec">
                            <div class="service-content-11">
                                <h1>What Our <span>Clients Says</span></h1>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12 service-sec">

                            <div class="container">
                                <div class="row">
                                    <div class="slider-service">
                                        <div class="slider-content">
                                            <div class="slider-box-service">
                                                <div class="slider-main-content">
                                                    <div class="slider-content-01">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/quote.png" alt="Quote Icon"
                                                            class="img-fluid">
                                                        <p>Whitepate is designed as a collaboration tool for
                                                            businesses that is a full project management solution.
                                                        </p>
                                                    </div>
                                                    <div class="slider-content-02">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/testi-client-01.png" alt="Slider Image"
                                                            class="img-fluid">
                                                        <div class="client-details">
                                                            <h4>Oberon Shaw, MCH</h4>
                                                            <p>Head of Talent Acquisition, North America</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="slider-content">
                                            <div class="slider-box-service">
                                                <div class="slider-main-content">
                                                    <div class="slider-content-01">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/quote.png" alt="Quote Icon"
                                                            class="img-fluid">
                                                        <p>Whitepate is designed as a collaboration tool for
                                                            businesses that is a full project management solution.
                                                        </p>
                                                    </div>
                                                    <div class="slider-content-02">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/testi-client-01.png" alt="Slider Image"
                                                            class="img-fluid">
                                                        <div class="client-details">
                                                            <h4>Oberon Shaw, MCH</h4>
                                                            <p>Head of Talent Acquisition, North America</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="slider-content">
                                            <div class="slider-box-service">
                                                <div class="slider-main-content">
                                                    <div class="slider-content-01">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/quote.png" alt="Quote Icon"
                                                            class="img-fluid">
                                                        <p>Whitepate is designed as a collaboration tool for
                                                            businesses that is a full project management solution.
                                                        </p>
                                                    </div>
                                                    <div class="slider-content-02">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/testi-client-01.png" alt="Slider Image"
                                                            class="img-fluid">
                                                        <div class="client-details">
                                                            <h4>Oberon Shaw, MCH</h4>
                                                            <p>Head of Talent Acquisition, North America</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="slider-content">
                                            <div class="slider-box-service">
                                                <div class="slider-main-content">
                                                    <div class="slider-content-01">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/quote.png" alt="Quote Icon"
                                                            class="img-fluid">
                                                        <p>Whitepate is designed as a collaboration tool for
                                                            businesses that is a full project management solution.
                                                        </p>
                                                    </div>
                                                    <div class="slider-content-02">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/testi-client-01.png" alt="Slider Image"
                                                            class="img-fluid">
                                                        <div class="client-details">
                                                            <h4>Oberon Shaw, MCH</h4>
                                                            <p>Head of Talent Acquisition, North America</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="slider-content">
                                            <div class="slider-box-service">
                                                <div class="slider-main-content">
                                                    <div class="slider-content-01">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/quote.png" alt="Quote Icon"
                                                            class="img-fluid">
                                                        <p>Whitepate is designed as a collaboration tool for
                                                            businesses that is a full project management solution.
                                                        </p>
                                                    </div>
                                                    <div class="slider-content-02">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/testi-client-01.png" alt="Slider Image"
                                                            class="img-fluid">
                                                        <div class="client-details">
                                                            <h4>Oberon Shaw, MCH</h4>
                                                            <p>Head of Talent Acquisition, North America</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="slider-content">
                                            <div class="slider-box-service">
                                                <div class="slider-main-content">
                                                    <div class="slider-content-01">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/quote.png" alt="Quote Icon"
                                                            class="img-fluid">
                                                        <p>Whitepate is designed as a collaboration tool for
                                                            businesses that is a full project management solution.
                                                        </p>
                                                    </div>
                                                    <div class="slider-content-02">
                                                        <img src="<?php bloginfo('template_directory'); ?>/assets/images/testi-client-01.png" alt="Slider Image"
                                                            class="img-fluid">
                                                        <div class="client-details">
                                                            <h4>Oberon Shaw, MCH</h4>
                                                            <p>Head of Talent Acquisition, North America</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!-- service section end -->

    <!-- service section 12 -->
    <section class="service-sec-12">
        <div class="container">
            <div class="row">
                <div class="container-fluid">
                    <div class="row align-items-center justify-content-center">

                        <div class="col-lg-12 col-md-12 col-sm-12 col-12 service-sec">
                            <!-- <img src="assets/images/service-bg01.png" alt="Hero Image" class="img-fluid"> -->
                            <div class="service-content-12">
                                <h1>Try Whitepace <br> <span>today</span></h1>
                                <p>Get started for free.<br>Add your whole team as your needs grow.</p>
                                <!-- <p>Add your whole team as your needs grow.</p> -->
                                <a href="#" class="main-btn-02">Read More <i class="fa-solid fa-arrow-right"></i></a>
                                <p>On a big team? Contact sales</p>
                                <div class="service-content-12-img">
                                    <img src="<?php bloginfo('template_directory'); ?>/assets/images/apple-white.png" alt="" class="img-fluid">
                                    <img src="<?php bloginfo('template_directory'); ?>/assets/images/windows-logo.png" alt="" class="img-fluid">
                                    <img src="<?php bloginfo('template_directory'); ?>/assets/images/android-logo.png" alt="" class="img-fluid">


                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- service section 12 end -->


<?php get_footer(); ?>
<?php get_footer('inner'); ?>