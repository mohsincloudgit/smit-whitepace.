<section class="footer-sec-01">
        <div class="container">
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-2 col-md-4 col-sm-6 quick-links">
                    <img src="<?php bloginfo('template_directory'); ?>/assets/images/logo-main.png" alt="Logo" class="img-fluid">
                    <p>whitepace was created for the new ways we live and work. We make a better workspace around the
                        world</p>

                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 quick-links">

                    <ul>
                        <h5>Product</h5>
                        <li><a href="#">Overview</a></li>
                        <li><a href="#">Pricing</a></li>
                        <li><a href="#">Customer stories</a></li>
                    </ul>

                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 quick-links">

                    <ul>
                        <h5>Resources</h5>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Guides & tutorials</a></li>
                        <li><a href="#">Help center</a></li>
                    </ul>

                </div>

                <div class="col-lg-2 col-md-4 col-sm-6 quick-links">

                    <ul>
                        <h5>Services</h5>
                        <li><a href="#">Company</a></li>
                        <li><a href="#">Careers </a></li>
                        <li><a href="#">Media kit</a></li>
                    </ul>

                </div>
                <div class="col-lg-2 col-md-4 col-sm-6 quick-links">


                    <h5>Try It Today</h5>
                    <p>Get started for free.
                        Add your whole team as your needs grow.</p>
                    <a href="#" class="main-btn-02">Start Today <i class="fa-solid fa-arrow-right"></i></a>
                </div>

            </div>
            <div class="coopyright">
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-lg-8 col-md-6 col-sm-12 col-12">
                            <p>© Copyright 2025 . My Books Publisher . All rights reserved.</p>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                            <ul class="footer-bottom">
                                <li><a href="terms-and-conditions">Terms &amp; Conditions</a></li> | 
                                <li><a href="privacy-policy">Privacy Policy</a></li>
                            </ul>

                        </div>

                    </div>


                </div>



            </div>
        </div>
</section>