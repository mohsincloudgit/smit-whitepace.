<?php 
register_nav_menus( array(
    'primary-menu'=> 'Top Menu' ),
);

add_theme_support( 'post-thumbnails' );

?>

